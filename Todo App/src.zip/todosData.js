const todosData = [
    {
        id: 1,
        text: "Take out the trash",
        completed: true,
        dueDate: null,
        importance: 4
    },
    {
        id: 2,
        text: "Grocery shopping",
        completed: false,
        dueDate: '2019-12-30',
        importance: 3
    },
    {
        id: 3,
        text: "Clean gecko tank",
        completed: false,
        dueDate: null,
        importance: 3
    },
    {
        id: 4,
        text: "Mow lawn",
        completed: true,
        dueDate: '2019-11-30',
        importance: 4
    },
    {
        id: 5,
        text: "Catch up on Arrested Development",
        completed: false,
        dueDate: '2019-11-28',
        importance: 1
    }
]

export default todosData